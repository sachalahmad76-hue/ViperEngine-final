# Viper Engine ProGuard Rules

# Keep OpenCV classes
-keep class org.opencv.** { *; }

# Keep all Viper Engine classes (Is ek line ne aapke Services aur CVEngine sab ko cover kar liya hai)
-keep class com.viperengine.** { *; }

# AndroidX
-dontwarn androidx.**
-keep class androidx.** { *; }

# Keep Serializable classes
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    !static !transient <fields>;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# Remove logging in release
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
}
