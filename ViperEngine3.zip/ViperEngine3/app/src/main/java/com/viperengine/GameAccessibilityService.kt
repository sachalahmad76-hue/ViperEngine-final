package com.viperengine

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.util.DisplayMetrics
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.accessibilityservice.AccessibilityServiceInfo
import kotlinx.coroutines.*

class GameAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private lateinit var displayMetrics: DisplayMetrics
    private var gameRunning = false
    private var isMyTurn = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        displayMetrics = resources.displayMetrics

        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                AccessibilityEvent.TYPE_VIEW_CLICKED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
            notificationTimeout = 100
        }
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName != "com.miniclip.eightballpool") return

        val engine = OverlayService.instance ?: return
        val settings = engine.getEngineSettings()
        val className = event.className?.toString() ?: ""

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                when {
                    // Game table detected — match started
                    className.contains("GameTable") || className.contains("TableScene") || className.contains("PlayScene") -> {
                        gameRunning = true
                        if (settings.autoplayEnabled) {
                            scope.launch {
                                delay(3000) // Wait for table to settle
                                playMatch(engine, settings)
                            }
                        }
                    }
                    // Result screen detected — match ended
                    className.contains("Result") || className.contains("GameOver") || className.contains("EndGame") -> {
                        gameRunning = false
                        if (settings.autoplayEnabled) {
                            scope.launch {
                                delay(2000)
                                handleEndGame(settings)
                            }
                        }
                    }
                    // Lobby or menu
                    className.contains("Lobby") || className.contains("Menu") || className.contains("Home") -> {
                        if (settings.autoplayEnabled && settings.autoQueueEnabled) {
                            scope.launch {
                                delay(1500)
                                findAndTapMatchButton()
                            }
                        }
                    }
                }
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                if (settings.autoplayEnabled) {
                    scope.launch {
                        autoTapButtons()
                    }
                }
            }
        }
    }

    private suspend fun playMatch(engine: OverlayService, settings: EngineSettings) {
        var shotCount = 0

        while (gameRunning && settings.autoplayEnabled) {
            // Wait for shot animation to finish
            delay(1500)

            // Capture screen
            val bitmap = engine.getScreenCapture().getLatestFrame()
            if (bitmap == null) {
                delay(500)
                continue
            }

            // Analyze with CV engine
            val shot = engine.getCVEngine().analyzeFrame(bitmap, true)
            if (shot == null) {
                delay(500)
                continue
            }

            // Anti-ban random delay
            val reactionTime = if (settings.safeMode) {
                (800L..2000L).random()
            } else {
                (200L..600L).random()
            }
            delay(reactionTime)

            // Execute the shot
            executeShot(shot)

            shotCount++
            delay(3000) // Wait for ball movement
        }
    }

    private suspend fun executeShot(shot: ShotData) {
        val scaleX = displayMetrics.widthPixels / 1080f
        val scaleY = displayMetrics.heightPixels / 1920f

        val centerX = shot.aimStart.x * scaleX
        val centerY = shot.aimStart.y * scaleY
        val aimX = shot.aimEnd.x * scaleX
        val aimY = shot.aimEnd.y * scaleY

        // Phase 1: Aim — drag from cue ball toward target
        val aimPath = Path().apply {
            moveTo(centerX, centerY)
            lineTo(aimX, aimY)
        }
        val aimStroke = GestureDescription.StrokeDescription(aimPath, 0, 300)
        val aimGesture = GestureDescription.Builder().addStroke(aimStroke).build()
        dispatchGesture(aimGesture, null, null)
        delay(500)

        // Phase 2: Power — pull back on the power meter
        val pullX = centerX - (aimX - centerX) * shot.power * 0.3f
        val pullY = centerY - (aimY - centerY) * shot.power * 0.3f
        val powerPath = Path().apply {
            moveTo(centerX, centerY)
            lineTo(pullX, pullY)
        }
        val powerStroke = GestureDescription.StrokeDescription(powerPath, 0, (shot.power * 500).toLong())
        val powerGesture = GestureDescription.Builder().addStroke(powerStroke).build()
        dispatchGesture(powerGesture, null, null)
        delay(300)

        // Phase 3: Shoot — quick tap
        val tapStroke = GestureDescription.StrokeDescription(
            Path().apply { moveTo(centerX, centerY) }, 0, 30
        )
        val shootGesture = GestureDescription.Builder().addStroke(tapStroke).build()
        dispatchGesture(shootGesture, null, null)
    }

    private suspend fun handleEndGame(settings: EngineSettings) {
        delay(3000)

        // Tap "Play Again" button
        findAndTapButton(listOf("play again", "play", "rematch"))

        if (settings.autoQueueEnabled) {
            delay(2000)

            if (settings.queueMode == 1) {
                // Single Table — select specific table
                findAndTapButton(listOf("mumbai", "shanghai", "rome", "berlin", "las vegas", "miami"))
            } else {
                // Mixer Join
                findAndTapButton(listOf("mixer", "quick join", "find match"))
            }
        }
    }

    private suspend fun findAndTapMatchButton() {
        findAndTapButton(listOf("play", "find match", "ok", "continue"))
    }

    private suspend fun autoTapButtons() {
        findAndTapButton(listOf("ok", "continue", "close", "x", "dismiss"))
    }

    private suspend fun findAndTapButton(targetTexts: List<String>) {
        val root = rootInActiveWindow ?: return
        scanAndTap(root, targetTexts)
    }

    private fun scanAndTap(node: AccessibilityNodeInfo?, texts: List<String>) {
        if (node == null) return
        val nodeText = node.text?.toString()?.lowercase() ?: ""
        val contentDesc = node.contentDescription?.toString()?.lowercase() ?: ""

        if (texts.any { it in nodeText || it in contentDesc }) {
            if (node.isClickable) {
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return
            }
        }
        for (i in 0 until node.childCount) {
            scanAndTap(node.getChild(i), texts)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}