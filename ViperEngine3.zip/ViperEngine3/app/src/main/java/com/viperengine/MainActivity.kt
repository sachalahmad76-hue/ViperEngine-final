package com.viperengine

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.android.material.textview.MaterialTextView

class MainActivity : AppCompatActivity() {

    private lateinit var powerManager: PowerManager
    private lateinit var mediaProjectionManager: MediaProjectionManager
    private val REQUEST_CODE_OVERLAY = 1001
    private val REQUEST_CODE_NOTIFICATION = 1002

    private lateinit var btnStartOverlay: MaterialButton
    private lateinit var btnOpenSettings: MaterialButton
    private lateinit var btnEnableAccessibility: MaterialButton
    private lateinit var btnGrantMediaProjection: MaterialButton
    private lateinit var btnDisableBatteryOptimization: MaterialButton
    private lateinit var tvOverlayStatus: MaterialTextView
    private lateinit var tvStatusIcon: TextView
    private lateinit var progressBar: ProgressBar

    // Settings toggles
    private lateinit var switchAutoPlay: SwitchMaterial
    private lateinit var switchAimAssist: SwitchMaterial
    private lateinit var switchReplayValidation: SwitchMaterial
    private lateinit var switchSafeMode: SwitchMaterial
    private lateinit var switchStyleCustomization: SwitchMaterial
    private lateinit var switchQueueManagement: SwitchMaterial
    private lateinit var switchSpinControl: SwitchMaterial
    private lateinit var switchBreakSettings: SwitchMaterial

    // Permission state tracking
    private var overlayPermissionGranted = false
    private var accessibilityEnabled = false
    private var mediaProjectionGranted = false
    private var notificationGranted = false

    // Media projection result launcher
    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            mediaProjectionGranted = true
            updateStatus("✓ Media Projection Allowed", true)
            saveMediaProjectionData(result.resultCode, result.data!!)
            Toast.makeText(this, "Media Projection Grant Ho Gaya ✅", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Media Projection Cancel Kar Diya ❌", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        setContentView(R.layout.activity_main)

        powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        initViews()
        checkPermissions()
        setupClickListeners()
        loadSavedSettings()
    }

    private fun initViews() {
        btnStartOverlay = findViewById(R.id.btnStartOverlay)
        btnOpenSettings = findViewById(R.id.btnOpenSettings)
        btnEnableAccessibility = findViewById(R.id.btnEnableAccessibility)
        btnGrantMediaProjection = findViewById(R.id.btnGrantMediaProjection)
        btnDisableBatteryOptimization = findViewById(R.id.btnDisableBatteryOptimization)
        tvOverlayStatus = findViewById(R.id.tvOverlayStatus)
        tvStatusIcon = findViewById(R.id.tvStatusIcon)
        progressBar = findViewById(R.id.progressBar)

        switchAutoPlay = findViewById(R.id.switchAutoPlay)
        switchAimAssist = findViewById(R.id.switchAimAssist)
        switchReplayValidation = findViewById(R.id.switchReplayValidation)
        switchSafeMode = findViewById(R.id.switchSafeMode)
        switchStyleCustomization = findViewById(R.id.switchStyleCustomization)
        switchQueueManagement = findViewById(R.id.switchQueueManagement)
        switchSpinControl = findViewById(R.id.switchSpinControl)
        switchBreakSettings = findViewById(R.id.switchBreakSettings)
    }

    private fun checkPermissions() {
        // Overlay Permission
        overlayPermissionGranted = Settings.canDrawOverlays(this)
        
        // Notification Permission (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationGranted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            notificationGranted = true
        }

        // Accessibility check
        accessibilityEnabled = isAccessibilityServiceEnabled()

        // Battery optimization check
        val batteryOptGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            powerManager.isIgnoringBatteryOptimizations(packageName)
        } else true

        updateUI()
    }

    private fun setupClickListeners() {
        btnStartOverlay.setOnClickListener {
            if (allPermissionsGranted()) {
                startOverlayService()
            } else {
                Toast.makeText(this, "Pehle Saare Permissions Do ✅", Toast.LENGTH_LONG).show()
            }
        }

        btnOpenSettings.setOnClickListener {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        }

        btnEnableAccessibility.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
        }

        btnGrantMediaProjection.setOnClickListener {
            val intent = mediaProjectionManager.createScreenCaptureIntent()
            mediaProjectionLauncher.launch(intent)
        }

        btnDisableBatteryOptimization.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            }
        }

        // Setup toggles
        setupToggle(R.id.switchAutoPlay, "auto_play")
        setupToggle(R.id.switchAimAssist, "aim_assist")
        setupToggle(R.id.switchReplayValidation, "replay_validation")
        setupToggle(R.id.switchSafeMode, "safe_mode")
        setupToggle(R.id.switchStyleCustomization, "style_customization")
        setupToggle(R.id.switchQueueManagement, "queue_management")
        setupToggle(R.id.switchSpinControl, "spin_control")
        setupToggle(R.id.switchBreakSettings, "break_settings")
    }

    private fun setupToggle(switchId: Int, prefKey: String) {
        val switch = findViewById<SwitchMaterial>(switchId)
        switch?.setOnCheckedChangeListener { _, isChecked ->
            getSharedPreferences("viper_prefs", MODE_PRIVATE)
                .edit()
                .putBoolean(prefKey, isChecked)
                .apply()
            // Send to overlay if running
            sendSettingsToOverlay()
        }
    }

    private fun loadSavedSettings() {
        val prefs = getSharedPreferences("viper_prefs", MODE_PRIVATE)
        switchAutoPlay.isChecked = prefs.getBoolean("auto_play", true)
        switchAimAssist.isChecked = prefs.getBoolean("aim_assist", true)
        switchReplayValidation.isChecked = prefs.getBoolean("replay_validation", true)
        switchSafeMode.isChecked = prefs.getBoolean("safe_mode", false)
        switchStyleCustomization.isChecked = prefs.getBoolean("style_customization", true)
        switchQueueManagement.isChecked = prefs.getBoolean("queue_management", true)
        switchSpinControl.isChecked = prefs.getBoolean("spin_control", true)
        switchBreakSettings.isChecked = prefs.getBoolean("break_settings", true)
    }

    private fun sendSettingsToOverlay() {
        val prefs = getSharedPreferences("viper_prefs", MODE_PRIVATE)
        val settings = mapOf(
            "auto_play" to prefs.getBoolean("auto_play", true),
            "aim_assist" to prefs.getBoolean("aim_assist", true),
            "replay_validation" to prefs.getBoolean("replay_validation", true),
            "safe_mode" to prefs.getBoolean("safe_mode", false),
            "style_customization" to prefs.getBoolean("style_customization", true),
            "queue_management" to prefs.getBoolean("queue_management", true),
            "spin_control" to prefs.getBoolean("spin_control", true),
            "break_settings" to prefs.getBoolean("break_settings", true)
        )
        // Broadcast to overlay service
        val intent = Intent("com.viperengine.SETTINGS_CHANGED")
        settings.forEach { (key, value) ->
            intent.putExtra(key, value)
        }
        sendBroadcast(intent)
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val service = "${packageName}/.GameAccessibilityService"
        try {
            val enabledServices = Settings.Secure.getString(
                contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return enabledServices.split(":").any { it.equals(service, ignoreCase = true) }
        } catch (e: Exception) {
            return false
        }
    }

    private fun allPermissionsGranted(): Boolean {
        return overlayPermissionGranted && accessibilityEnabled && 
               mediaProjectionGranted && notificationGranted
    }

    private fun startOverlayService() {
        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        updateStatus("✅ Viper Engine Chal Raha Hai!", true)
        Toast.makeText(this, "🔥 Viper Engine Active! Game Open Karo", Toast.LENGTH_LONG).show()
    }

    private fun saveMediaProjectionData(resultCode: Int, data: Intent) {
        getSharedPreferences("viper_prefs", MODE_PRIVATE)
            .edit()
            .putInt("media_projection_result_code", resultCode)
            .apply()
    }

    private fun updateStatus(text: String, isSuccess: Boolean) {
        tvOverlayStatus.text = text
        tvOverlayStatus.setTextColor(
            if (isSuccess) getColor(android.R.color.holo_green_dark)
            else getColor(android.R.color.holo_orange_dark)
        )
        tvStatusIcon.text = if (isSuccess) "✅" else "⚠️"
    }

    private fun updateUI() {
        val allGranted = allPermissionsGranted()
        
        btnStartOverlay.isEnabled = allGranted
        btnStartOverlay.alpha = if (allGranted) 1.0f else 0.5f

        btnOpenSettings.isEnabled = !overlayPermissionGranted
        btnEnableAccessibility.isEnabled = !accessibilityEnabled
        btnGrantMediaProjection.isEnabled = !mediaProjectionGranted
        btnDisableBatteryOptimization.isEnabled = !isIgnoringBatteryOptimizations()

        updateStatus(
            if (allGranted) "✅ All Permissions Granted! Start Karo"
            else "⚠️ Permissions Required",
            allGranted
        )
    }

    private fun isIgnoringBatteryOptimizations(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            powerManager.isIgnoringBatteryOptimizations(packageName)
        } else true
    }

    override fun onResume() {
        super.onResume()
        checkPermissions()
    }
}