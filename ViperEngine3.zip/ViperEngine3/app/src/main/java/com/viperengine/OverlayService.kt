package com.viperengine

import android.app.*
import android.content.*
import android.graphics.*
import android.os.*
import android.view.*
import android.widget.*
import kotlinx.coroutines.*

class OverlayService : Service() {

    companion object { var instance: OverlayService? = null }

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: View
    lateinit var cvEngine: CVEngine
    lateinit var screenCapture: ScreenCaptureManager
    val settings = EngineSettings()
    private lateinit var aimCanvas: View

    override fun onCreate() {
        super.onCreate()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        cvEngine = CVEngine()
        screenCapture = ScreenCaptureManager(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel("viper_channel", "Viper Engine", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        startForeground(1, Notification.Builder(this, "viper_channel")
            .setContentTitle("Viper Engine").setContentText("Running")
            .setSmallIcon(android.R.drawable.ic_menu_compass).build())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        showFloatingPanel()
        showAimOverlay()
        if (intent?.hasExtra("mediaProjectionResultCode") == true) {
            val rc = intent.getIntExtra("mediaProjectionResultCode", 0)
            val d = intent.getSerializableExtra("mediaProjectionData") as? Intent
            if (d != null) screenCapture.startCapture(d, rc)
        }
        return START_STICKY
    }

    private fun showFloatingPanel() {
        val params = WindowManager.LayoutParams(
            300, WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 30
        params.y = 150

        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_widget, null)
        setupAllControls()
        windowManager.addView(overlayView, params)

        // Drag handle
        overlayView.findViewById<View>(R.id.dragHandle).setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> true
                MotionEvent.ACTION_MOVE -> {
                    params.x = (event.rawX - 150).toInt()
                    params.y = (event.rawY - 30).toInt()
                    windowManager.updateViewLayout(overlayView, params)
                    true
                }
                else -> false
            }
        }
    }

    private fun setupAllControls() {
        // --- TAB 1: BASIC SETTINGS ---
        // Show Line
        val swShowLine = overlayView.findViewById<Switch>(R.id.swShowLine)
        swShowLine.setOnCheckedChangeListener { _, b -> settings.showLine = b; aimCanvas.invalidate() }

        // Show Pockets
        val swShowPockets = overlayView.findViewById<Switch>(R.id.swShowPockets)
        swShowPockets.setOnCheckedChangeListener { _, b -> settings.showPockets = b; aimCanvas.invalidate() }

        // Show Power
        val swShowPower = overlayView.findViewById<Switch>(R.id.swShowPower)
        swShowPower.setOnCheckedChangeListener { _, b -> settings.showPower = b; aimCanvas.invalidate() }

        // Show Rebound Lines
        val swRebound = overlayView.findViewById<Switch>(R.id.swRebound)
        swRebound.setOnCheckedChangeListener { _, b -> settings.showRebound = b; aimCanvas.invalidate() }

        // Show Spin
        val swShowSpin = overlayView.findViewById<Switch>(R.id.swShowSpin)
        swShowSpin.setOnCheckedChangeListener { _, b -> settings.showSpin = b }

        // Safe Mode
        val swSafeMode = overlayView.findViewById<Switch>(R.id.swSafeMode)
        swSafeMode.setOnCheckedChangeListener { _, b -> settings.safeMode = b }

        // Enable Jump
        val swJump = overlayView.findViewById<Switch>(R.id.swJump)
        swJump.setOnCheckedChangeListener { _, b -> settings.jumpEnabled = b }

        // Enable Spin
        val swSpin = overlayView.findViewById<Switch>(R.id.swSpin)
        swSpin.setOnCheckedChangeListener { _, b -> settings.spinEnabled = b }

        // Auto Spin
        val swAutoSpin = overlayView.findViewById<Switch>(R.id.swAutoSpin)
        swAutoSpin.setOnCheckedChangeListener { _, b -> settings.autoSpin = b }

        // Line Out Fix Button
        val btnLineOutFix = overlayView.findViewById<Button>(R.id.btnLineOutFix)
        btnLineOutFix.setOnClickListener {
            settings.lineOutFix = !settings.lineOutFix
            Toast.makeText(this, "Line Out Fix: ${if(settings.lineOutFix)"ON" else "OFF"}", Toast.LENGTH_SHORT).show()
        }

        // --- TAB 2: AUTOPLAY SETTINGS ---
        // Enable Autoplay
        val swAutoPlay = overlayView.findViewById<Switch>(R.id.swAutoplay)
        swAutoPlay.setOnCheckedChangeListener { _, b -> settings.autoplayEnabled = b }

        // Autoplay Mode
        val spinMode = overlayView.findViewById<Spinner>(R.id.spinAutoplayMode)
        ArrayAdapter.createFromResource(this, R.array.autoplay_modes, android.R.layout.simple_spinner_item)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); spinMode.adapter = it }
        spinMode.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { settings.autoplayMode = pos }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // Force Break
        val swForceBreak = overlayView.findViewById<Switch>(R.id.swForceBreak)
        swForceBreak.setOnCheckedChangeListener { _, b -> settings.forceBreak = b }

        // Illegal Break
        val swIllegalBreak = overlayView.findViewById<Switch>(R.id.swIllegalBreak)
        swIllegalBreak.setOnCheckedChangeListener { _, b -> settings.illegalBreak = b }

        // Break Type spinner
        val spinBreak = overlayView.findViewById<Spinner>(R.id.spinBreakType)
        ArrayAdapter.createFromResource(this, R.array.break_types, android.R.layout.simple_spinner_item)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); spinBreak.adapter = it }
        spinBreak.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { settings.breakType = pos }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // Shard Position spinner
        val spinShard = overlayView.findViewById<Spinner>(R.id.spinShardPos)
        ArrayAdapter.createFromResource(this, R.array.shard_positions, android.R.layout.simple_spinner_item)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); spinShard.adapter = it }

        // Coin % slider
        val seekCoin = overlayView.findViewById<SeekBar>(R.id.seekCoinPercent)
        val tvCoin = overlayView.findViewById<TextView>(R.id.tvCoinPercent)
        seekCoin.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, b: Boolean) { settings.coinPercent = p; tvCoin.text = "$p%" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // --- TAB 3: QUEUE SETTINGS ---
        // Enable Auto Queue
        val swAutoQueue = overlayView.findViewById<Switch>(R.id.swAutoQueue)
        swAutoQueue.setOnCheckedChangeListener { _, b -> settings.autoQueueEnabled = b }

        // Queue Mode spinner
        val spinQueue = overlayView.findViewById<Spinner>(R.id.spinQueueMode)
        ArrayAdapter.createFromResource(this, R.array.queue_modes, android.R.layout.simple_spinner_item)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); spinQueue.adapter = it }
        spinQueue.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { settings.queueMode = pos }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // Table Select spinner
        val spinTable = overlayView.findViewById<Spinner>(R.id.spinTableSelect)
        ArrayAdapter.createFromResource(this, R.array.tables, android.R.layout.simple_spinner_item)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); spinTable.adapter = it }
        spinTable.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { settings.selectedTable = pos }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // Auto Reconnect
        val swReconnect = overlayView.findViewById<Switch>(R.id.swAutoReconnect)
        swReconnect.setOnCheckedChangeListener { _, b -> settings.autoReconnect = b }

        // --- TAB 4: STYLE SETTINGS ---
        // Line Color spinner
        val spinColor = overlayView.findViewById<Spinner>(R.id.spinLineColor)
        ArrayAdapter.createFromResource(this, R.array.line_colors, android.R.layout.simple_spinner_item)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); spinColor.adapter = it }
        spinColor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                settings.lineColor = when(pos) { 0->Color.GREEN; 1->Color.RED; 2->Color.BLUE; 3->Color.YELLOW; 4->Color.CYAN; 5->Color.MAGENTA; else->Color.WHITE }
                aimCanvas.invalidate()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // Line Thickness spinner
        val spinThick = overlayView.findViewById<Spinner>(R.id.spinLineThickness)
        ArrayAdapter.createFromResource(this, R.array.line_thickness, android.R.layout.simple_spinner_item)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); spinThick.adapter = it }
        spinThick.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                settings.lineThickness = when(pos) { 0->2f; 1->4f; else->6f }
                aimCanvas.invalidate()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun showAimOverlay() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        aimCanvas = object : View(this) {
            private val linePaint = Paint().apply { style = Paint.Style.STROKE; isAntiAlias = true }
            private val pocketPaint = Paint().apply { style = Paint.Style.FILL; isAntiAlias = true }
            private val textPaint = Paint().apply { color = Color.WHITE; textSize = 24f; isAntiAlias = true }

            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                if (!settings.showLine) return

                linePaint.color = settings.lineColor
                linePaint.strokeWidth = settings.lineThickness

                // 1. Show Aim Line
                cvEngine.currentAimLine?.let { (start, end) ->
                    canvas.drawLine(start.x, start.y, end.x, end.y, linePaint)
                }

                // 2. Show Rebound Lines (dashed)
                if (settings.showRebound) {
                    cvEngine.reboundLines?.forEach { line ->
                        val rp = Paint(linePaint).apply {
                            alpha = 120; pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)
                        }
                        canvas.drawLine(line.first.x, line.first.y, line.second.x, line.second.y, rp)
                    }
                }

                // 3. Show Pockets
                if (settings.showPockets) {
                    pocketPaint.color = Color.argb(80, 255, 200, 0)
                    cvEngine.pockets?.forEach { p -> canvas.drawCircle(p.x, p.y, 30f, pocketPaint) }
                    pocketPaint.color = Color.argb(150, 255, 255, 0)
                    cvEngine.pockets?.forEach { p -> canvas.drawCircle(p.x, p.y, 15f, pocketPaint) }
                }

                // 4. Show Power Meter
                if (settings.showPower && cvEngine.currentPower != null) {
                    val power = cvEngine.currentPower!!
                    val mx = 60f; val my = height - 200f; val mw = 25f; val mh = 150f
                    canvas.drawRect(mx, my, mx+mw, my+mh, Paint().apply { color = Color.argb(80,0,0,0) })
                    val fillPaint = Paint().apply { color = when { power > 0.7f -> Color.RED; power > 0.4f -> Color.YELLOW; else -> Color.GREEN } }
                    canvas.drawRect(mx, my+mh-(mh*power), mx+mw, my+mh, fillPaint)
                    canvas.drawText("PWR", mx-5, my-10, textPaint)
                }

                // 5. Show Spin Indicator
                if (settings.showSpin && cvEngine.currentSpin != null) {
                    val sp = cvEngine.currentSpin!!
                    val sx = width/2f; val sy = height - 80f; val sr = 35f
                    canvas.drawCircle(sx, sy, sr, Paint().apply { color = Color.argb(100,255,255,255); style = Paint.Style.STROKE; strokeWidth = 2f })
                    canvas.drawLine(sx, sy, sx+sp.first*25, sy+sp.second*25, Paint().apply { color = Color.YELLOW; strokeWidth = 3f })
                }
            }
        }
        windowManager.addView(aimCanvas, params)
    }

    fun getEngineSettings() = settings
    fun getCVEngine() = cvEngine
    fun getScreenCapture() = screenCapture
    override fun onBind(intent: Intent?) = null
}

// ============= ENGINE SETTINGS =============
data class EngineSettings(
    // Basic
    var showLine: Boolean = true, var showPockets: Boolean = true,
    var showPower: Boolean = true, var showRebound: Boolean = true,
    var showSpin: Boolean = false, var safeMode: Boolean = true,
    var lineOutFix: Boolean = false, var jumpEnabled: Boolean = false,
    var spinEnabled: Boolean = false, var autoSpin: Boolean = false,

    // Autoplay
    var autoplayEnabled: Boolean = false, var autoplayMode: Int = 0,
    var forceBreak: Boolean = false, var illegalBreak: Boolean = false,
    var breakType: Int = 0, var coinPercent: Int = 30,

    // Queue
    var autoQueueEnabled: Boolean = false, var queueMode: Int = 0,
    var selectedTable: Int = 0, var autoReconnect: Boolean = true,

    // Style
    var lineColor: Int = Color.GREEN, var lineThickness: Float = 4f
)